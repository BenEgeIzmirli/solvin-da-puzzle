from board import *
from timing import *
from piece import *
import copy
from my_exceptions import *
import sys
import __builtin__
from plausible import *

stop_considering_edges = 6

def yield_all_fits(board,piece,rec_lvl):
    working_copy = copy.deepcopy(board)
    if rec_lvl<stop_considering_edges:
        num_edges = 2
    else:
        num_edges = None
    for p in piece.rotations():
        for t in board.unoccupied():
            try:
                working_copy.place(piece,t.coords,num_edges)
                pl = plausible(working_copy)
                if not pl:
                    piece.clean()
                    working_copy.unplace(piece.piece_name)
                    if rec_lvl<6:
                        continue
                    else:
                        return
                y = copy.deepcopy(working_copy)
                yield y
                working_copy.unplace(piece.piece_name)
                piece.clean()
            except (DirectionException, EdgeException, InitializationException):
                continue

def all_pieces_placeable(board,pieces,rec_lvl):
    if rec_lvl<stop_considering_edges:
        return True
    for pn in pieces:
        p = Piece(pn)
        at_least_one_placement_of_this_piece = False
        for s in yield_all_fits(board,p,rec_lvl):
            at_least_one_placement_of_this_piece = True
            break
        if at_least_one_placement_of_this_piece == False:
            print "couldn't place piece",pn,"on this board:"
            board.print_board()
            print 
            return pn
    return True

def print_progress(board,rec_lvl):
    #print '##########################'
    print "couldn't find any solns for board at rec_lvl",rec_lvl
    board.print_board()
    return

def depth_first_search(previous_solution=None,pieces=None,rec_lvl=0):
    if pieces==None:
        pieces = ['boat','tie','check','line','v','heart','s','hexagon','mountains','fedex','nike','weird']
    if previous_solution==None:
        previous_solution = Board()
    if previous_solution.is_solved():
        yield previous_solution
    for pn in pieces:
        p = Piece(pn)
        new_pieces = copy.deepcopy(pieces)
        new_pieces.remove(pn)
        for ns in yield_all_fits(previous_solution,p,rec_lvl):
            #print "trying to place:",new_pieces
            unplaceable_piece = all_pieces_placeable(ns,new_pieces,rec_lvl+1)
            if unplaceable_piece != True:
                print_progress(ns,rec_lvl)
                continue
            for sol in depth_first_search(ns,new_pieces,rec_lvl=rec_lvl+1):
                yield sol
            print_progress(ns,rec_lvl)













