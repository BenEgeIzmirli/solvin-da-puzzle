class EdgeException(Exception):
    pass
class DirectionException(Exception):
    pass
class InitializationException(Exception):
    pass